var colors = ["#b71c1c", "#880e4f", "#4a148c", "#0d47a1", "#006064", "#1b5e20", "#827717", "#ff6f00", "#212121", "#b71c1c", "#880e4f", "#4a148c", "#0d47a1", "#006064", "#1b5e20", "#827717", "#ff6f00", "#212121"];
Chart.defaults.global.animation.duartion = 10, Chart.defaults.global.devicePixelRatio = 10, $("ul.pull-right li.dropdown").last().find("a").first().find(".muted").hide();
var userName = $("ul.pull-right li.dropdown").last().find("a").first().find("span span").first().text().trim(),
  bingAPIKey = "AnLVuIekXyEvbagcmNli9pgb0bC6rBSbLoiIwqpG4YzxhnZII44HkTMwFN8bPEpI",
  mapquestAPIKey = "cWthMOAPfdye1t02NcpkzD30NVLfhNy6",
  adminState = !0;

function injectScript(content, id, tag) {
  $("script#" + id).remove();
  var node = document.getElementsByTagName(tag)[0],
    script = document.createElement("script");
  script.setAttribute("type", "text/javascript"), script.innerHTML = content, script.id = id, node.appendChild(script);
}

function setTextColorByLuma(rgb) {
  var c = rgb.substring(1);
  return .2126 * ((rgb = parseInt(c, 16)) >> 16 & 255) + .7152 * (rgb >> 8 & 255) + .0722 * (rgb >> 0 & 255) < 140 ? "#ffffff" : "#000000";
}

function rgb2hex(rgb) {
  return (rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i)) && 4 === rgb.length ? ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2) + ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2) + ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2) : "";
}

function copyToClipboard(text) {
  if (window.clipboardData && window.clipboardData.setData) return window.clipboardData.setData("Text", text);
  if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
    var textarea = document.createElement("textarea");
    textarea.textContent = text, textarea.style.position = "fixed", document.body.appendChild(textarea), textarea.select();
    try {
      return document.execCommand("copy");
    } catch (ex) {
      return console.warn("Copy to clipboard failed.", ex), !1;
    } finally {
      document.body.removeChild(textarea);
    }
  }
}

function orphanText(element) {
  return element.contents().filter(function() {
    return 3 === this.nodeType;
  }).text().trim();
}

function isOdd(num) {
  return num % 2;
}
$("ul.nav:not(.pull-right) > li").each(function() {
  $(this).find("span").text($(this).find("span").text().replace(String.fromCharCode(160) + String.fromCharCode(160) + "Users", "").replace(String.fromCharCode(160) + String.fromCharCode(160) + "Account", ""));
});
